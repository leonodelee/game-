// ɨ��.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "ɨ��.h"
#include "MineMap.h"
#include<windowsx.h>

#define MAX_LOADSTRING 100

// ȫ�ֱ���: 
HINSTANCE hInst;								// ��ǰʵ��
TCHAR szTitle[MAX_LOADSTRING];					// �������ı�
TCHAR szWindowClass[MAX_LOADSTRING];			// ����������
CMineMap m_Map;
int nflag = 0;

// �˴���ģ���а����ĺ�����ǰ������: 
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Setting(HWND, UINT, WPARAM, LPARAM);
int APIENTRY _tWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPTSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO:  �ڴ˷��ô��롣
	MSG msg;
	HACCEL hAccelTable;
	// ��ʼ��ȫ���ַ���
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MY, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// ִ��Ӧ�ó����ʼ��: 
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MY));

	// ����Ϣѭ��: 
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  ����:  MyRegisterClass()
//
//  Ŀ��:  ע�ᴰ���ࡣ
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MY));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_MY);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   ����:  InitInstance(HINSTANCE, int)
//
//   Ŀ��:  ����ʵ�����������������
//
//   ע��: 
//
//        �ڴ˺����У�������ȫ�ֱ����б���ʵ�������
//        ��������ʾ�����򴰿ڡ�
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;
   int l = m_Map.mx * 20 + 16;
   int r = m_Map.my * 20 + 99;
   hInst = hInstance; // ��ʵ������洢��ȫ�ֱ�����

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, l, r, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  ����:  WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  Ŀ��:    ���������ڵ���Ϣ��
//
//  WM_COMMAND	- ����Ӧ�ó���˵�
//  WM_PAINT	- ����������
//  WM_DESTROY	- �����˳���Ϣ������
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc, hdcMem;
	static HBITMAP hBitmap,bmpfame,bmpface,bmpnub;
	int px, py, n, m;
	px = GET_X_LPARAM(lParam);
	py = GET_Y_LPARAM(lParam);
	m = px / 20;
	n = py / 20 - 2;
	CRect rc(20 * m, 20 * n + 40, 20 * m + 20, 20 * n + 60),crc;
	static clock_t clnow=0;
	static int x = m;
	static int y = n;
	int rm = m_Map.rMine,rt=m_Map.timer ;
	switch (message)
	{
	case WM_CREATE:
		m_Map.Create();
		hBitmap = (HBITMAP)LoadImage((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), TEXT("��Ŀ1.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		bmpnub = (HBITMAP)LoadImage((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), TEXT("��Ŀ2.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		bmpfame = (HBITMAP)LoadImage((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), TEXT("��Ŀ3.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		bmpface = (HBITMAP)LoadImage((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), TEXT("��Ŀ4.bmp"),
			IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		SetTimer(hWnd, 1, 1000, NULL);
		break;
	case WM_COMMAND:
		wmId = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// �����˵�ѡ��: 
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		case ID_BEGAIN:
			m_Map.Create();
			InvalidateRect(hWnd, CRect(0, 0, m_Map.mx * 20, m_Map.my * 20 + 40), 0);
			break;
		case ID_32776:
			if (DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), hWnd, Setting))
			{
				GetWindowRect(hWnd, &crc);
				MoveWindow(hWnd, crc.left, crc.top, m_Map.mx * 20 + 16, m_Map.my * 20 + 99, 1);
				InvalidateRect(hWnd, CRect(0, 0, m_Map.mx * 20, m_Map.my * 20 + 40), 0);
			}
			break;
		case ID_32773:
			m_Map.mx = 10;
			m_Map.my = 8;
			m_Map.nMime = 15;
			m_Map.Create();
			GetWindowRect(hWnd,&crc);
			MoveWindow(hWnd, crc.left, crc.top, m_Map.mx * 20 + 16, m_Map.my * 20 + 99, 1);
			break;
		case ID_32774:
			m_Map.mx = 20;
			m_Map.my = 18;
			m_Map.nMime = 50;
			m_Map.Create();
			GetWindowRect(hWnd, &crc);
			MoveWindow(hWnd, crc.left, crc.top, m_Map.mx * 20 + 16, m_Map.my * 20 + 99, 1);
			break;
		case ID_32775:
			m_Map.mx = 30;
			m_Map.my = 20;
			m_Map.nMime = 100;
			m_Map.Create();
			GetWindowRect(hWnd, &crc);
			MoveWindow(hWnd, crc.left, crc.top, m_Map.mx * 20 + 16, m_Map.my * 20 + 99, 1);
			break;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO:  �ڴ����������ͼ����...
		hdcMem = CreateCompatibleDC(hdc);
		SelectObject(hdcMem, hBitmap);
		int i, j;
		for (i = 0; i < m_Map.mx; i++)
		{
			for (j = 0; j < m_Map.my; j++)
			{
				if (m_Map.Map[i][j] >= 0 && m_Map.Map[i][j] < 9)
				{
					BitBlt(hdc, i * 20, j * 20 + 40, 20, 20, hdcMem, m_Map.Map[i][j] * 20, 0, SRCCOPY);
				}
				if (m_Map.Map[i][j]>90)
					BitBlt(hdc, i * 20, j * 20 + 40, 20, 20, hdcMem, 10 * 20, 0, SRCCOPY);
				if (m_Map.Map[i][j] == -1)
					BitBlt(hdc, i * 20, j * 20 + 40, 20, 20, hdcMem, 9 * 20, 0, SRCCOPY);
				if (m_Map.Map[i][j] == -2)
					BitBlt(hdc, i * 20, j * 20 + 40, 20, 20, hdcMem, 12 * 20, 0, SRCCOPY);
				if (m_Map.Map[i][j] > 40 && m_Map.Map[i][j] < 60)
					BitBlt(hdc, i * 20, j * 20 + 40, 20, 20, hdcMem, 11 * 20, 0, SRCCOPY);
			}
		}
		SelectObject(hdcMem, bmpfame);
		BitBlt(hdc, 0, 0, 70, 40, hdcMem, 0, 0, SRCCOPY);
		BitBlt(hdc, m_Map.mx * 10 - 20, 0, 40, 40, hdcMem, 80, 0, SRCCOPY);
		BitBlt(hdc, m_Map.mx * 20 - 70, 0, 70, 40, hdcMem, 130, 0, SRCCOPY);
		StretchBlt(hdc, 70, 0, m_Map.mx * 10 - 90, 40, hdcMem, 70, 0, 10, 40, SRCCOPY);
		StretchBlt(hdc, m_Map.mx * 10 + 20, 0, m_Map.mx * 10 - 90, 40, hdcMem, 70, 0, 10, 40, SRCCOPY);
		SelectObject(hdcMem, bmpface);
		BitBlt(hdc, m_Map.mx * 10 - 12, 7, 24, 24, hdcMem, m_Map.winf * 24, 0, SRCCOPY);
		SelectObject(hdcMem, bmpnub);
		if (rm < 0) rm = 0;
		BitBlt(hdc, 6, 5, 20, 28, hdcMem, rm / 100 * 20, 0, SRCCOPY);
		if (rm >= 100) rm %= 100;
		BitBlt(hdc, 26, 5, 20, 28, hdcMem, rm / 10 * 20, 0, SRCCOPY);
		BitBlt(hdc, 46, 5, 20, 28, hdcMem, rm % 10 * 20, 0, SRCCOPY);
		if (rt >= 1000) rt %= 1000;
		BitBlt(hdc, m_Map.mx*20-66, 5, 20, 28, hdcMem, rt / 100 * 20, 0, SRCCOPY);
		if (rt >= 100) rt %= 100;
		BitBlt(hdc, m_Map.mx*20 - 46, 5, 20, 28, hdcMem, rt / 10 * 20, 0, SRCCOPY);
		BitBlt(hdc, m_Map.mx*20 - 26, 5, 20, 28, hdcMem, rt % 10 * 20, 0, SRCCOPY);
		DeleteDC(hdcMem);
		EndPaint(hWnd, &ps);
		break;
	case WM_LBUTTONUP:
		ReleaseCapture();
		nflag = 0;
		if (!m_Map.winf || m_Map.winf == 2)
			break;
		if (m >= m_Map.mx || m < 0 || n >= m_Map.my || n < 0 || m_Map.Map[m][n] < 90)
			break;
		m_Map.LClinck(m, n, &rc);
		if (m_Map.iswin())
			m_Map.winf = 2;
		if (m_Map.winf == 3)
			m_Map.winf = 1;
		InvalidateRect(hWnd, CRect(m_Map.mx * 10 - 12, 7, m_Map.mx * 10 + 12, 31), 0);
		InvalidateRect(hWnd, &rc, 0);
		break;
	case WM_RBUTTONDOWN:
		if (!m_Map.winf || m_Map.winf == 2)
			break;
		if (m >= m_Map.mx || m < 0 || n >= m_Map.my || n < 0 || m_Map.Map[m][n] <= 40)
			break;
		m_Map.Onrbtdown(m, n);
		InvalidateRect(hWnd, &rc, 0);
		InvalidateRect(hWnd, CRect(6, 5, 66, 33), 0);
		break;
	case WM_LBUTTONDOWN:
		SetCapture(hWnd);
		nflag = 1;
		x = m; y = n;
		if (!m_Map.winf || m_Map.winf == 2)
		{
			if (px >  m_Map.mx * 10 - 15 && px< m_Map.mx * 10 + 15 && py>4 && py < 34)
			{
				m_Map.Create();
				InvalidateRect(hWnd, CRect(0, 0, m_Map.mx * 20, m_Map.my * 20 + 40), 0);
			}
			break;
		}
		clock_t t;
		t = clock();
		if (t - clnow < 200)
		{
			if (m >= m_Map.mx || m < 0 || n >= m_Map.my || n < 0 || m_Map.Map[m][n]>90)
				break;
			m_Map.Onlbtdbc(m, n, &rc);
			if (m_Map.iswin())
			{
				m_Map.winf = 2;
				InvalidateRect(hWnd, CRect(m_Map.mx * 10 - 12, 7, m_Map.mx * 10 + 12, 31), 0);
			}
			if (m_Map.iswin())
				m_Map.winf = 2;
			InvalidateRect(hWnd, &rc, 0);
		}
		else{
			if (m >= m_Map.mx || m < 0 || n >= m_Map.my || n < 0 || m_Map.Map[m][n] < 90)
			{
				clnow = clock(); break;
			}
			hdc = GetDC(hWnd);
			SelectObject(hdc, GetStockObject(DC_BRUSH));
			SelectObject(hdc, GetStockObject(DC_PEN));
			SetDCBrushColor(hdc, RGB(230, 230, 230));
			SetDCPenColor(hdc, RGB(230, 230, 230));
			Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
			ReleaseDC(hWnd, hdc);
			m_Map.winf = 3;
			InvalidateRect(hWnd, CRect(m_Map.mx * 10 - 12, 7, m_Map.mx * 10 + 12, 31), 0);
		}
		clnow = clock();
		break;
	case WM_MOUSEMOVE:
	{
						 if (!nflag ||( m_Map.winf != 1 && m_Map.winf != 3))
							 break;
						 static int f1 = 1, f2 = 1;

						 if (m >= m_Map.mx || m < 0 || n >= m_Map.my || n < 0 || m_Map.Map[m][n] < 90)
						 {
							 if (f1){
								 InvalidateRect(hWnd, CRect(x*20,y*20+40,x*20+20,y*20+60), 0);
								 m_Map.winf = 1;
								 InvalidateRect(hWnd, CRect(m_Map.mx * 10 - 12, 7, m_Map.mx * 10 + 12, 31), 0);
								 f1 = 0; f2 = 1;
							 }
							 break;
						 }
						 if (f2)
						 {
							 m_Map.winf = 3;
							 InvalidateRect(hWnd, CRect(m_Map.mx * 10 - 12, 7, m_Map.mx * 10 + 12, 31), 0);
						 }
						 if (x != m || y != n)
						 {
							 CRect rc(20 * x, 20 * y + 40, 20 * x + 20, 20 * y + 60);
							 InvalidateRect(hWnd, &rc, 0);
						 }
						 hdc = GetDC(hWnd);
						 SelectObject(hdc, GetStockObject(DC_BRUSH));
						 SelectObject(hdc, GetStockObject(DC_PEN));
						 SetDCBrushColor(hdc, RGB(230, 230, 230));
						 SetDCPenColor(hdc, RGB(230, 230, 230));
						 Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
						 ReleaseDC(hWnd, hdc);
						 x = m; y = n; f1 = 1; f2 = 0;
						 break;
	}
	case WM_TIMER:
		if ((m_Map.winf == 1 || m_Map.winf == 3) && m_Map.first == 0)
		{
			m_Map.timer++;
			InvalidateRect(hWnd, CRect(m_Map.mx * 20 - 66, 5, m_Map.mx*20 - 6, 34), 0);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// �����ڡ������Ϣ��������
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
INT_PTR CALLBACK Setting(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND hEdit;
	TCHAR str[5];
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		hEdit = GetDlgItem(hDlg, IDC_EDIT1);
		swprintf_s(str, _countof(str), _T("%d"), m_Map.mx);
		SetWindowText(hEdit,str);
		hEdit = GetDlgItem(hDlg, IDC_EDIT2);
		swprintf_s(str, _countof(str), _T("%d"), m_Map.my);
		SetWindowText(hEdit, str);
		hEdit = GetDlgItem(hDlg, IDC_EDIT3);
		swprintf_s(str, _countof(str), _T("%d"), m_Map.nMime);
		SetWindowText(hEdit, str);
		break;
	case WM_SYSCOMMAND:
		if (wParam == SC_CLOSE)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)FALSE;
		}
		break;
	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK )
		{
			int a, b, c;
			hEdit = GetDlgItem(hDlg, IDC_EDIT1);
			GetWindowText(hEdit, str, 4);
			if ((a = _ttoi(str)) < 10||a>40)
			{
				MessageBox(hDlg,_T("�����������10��С��40"),_T("�Զ���"),MB_OK);
				break;
			}
			hEdit = GetDlgItem(hDlg, IDC_EDIT2);
			GetWindowText(hEdit, str, 4);
			if ((b = _ttoi(str)) < 1 || b>30)
			{
				MessageBox(hDlg, _T("�����������10��С��30"), _T("�Զ���"), MB_OK);
				break;
			}
			hEdit = GetDlgItem(hDlg, IDC_EDIT3);
			GetWindowText(hEdit, str, 4);
			if ((c = _ttoi(str)) < 1)
			{
				MessageBox(hDlg, _T("�����������0"), _T("�Զ���"), MB_OK);
				break;
			}
			if (c>a*b/2)
			{
				MessageBox(hDlg, _T("����̫��"), _T("�Զ���"), MB_OK);
				break;
			}
			m_Map.mx = a;
			m_Map.my = b;
			m_Map.nMime = c;
			m_Map.Create();
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)FALSE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}